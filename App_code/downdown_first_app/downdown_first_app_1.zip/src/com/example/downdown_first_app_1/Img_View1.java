package com.example.downdown_first_app_1;

import java.util.HashMap;
import java.util.Random;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.view.View;

public class Img_View1 extends View{
	BitmapDrawable ch_Img[] = new BitmapDrawable[3];
	BitmapDrawable Back_Img1 = null;
	BitmapDrawable btn_left[] = new BitmapDrawable[2];
	BitmapDrawable btn_right[] = new BitmapDrawable[2];
	BitmapDrawable cloud_ch_img[] = new BitmapDrawable[3];
	Context _context;
	SoundPool msoundpool;
	HashMap<Integer,Integer>msoundpoolmap;
	AudioManager maudiomanager;
	int vol=0;
	MediaPlayer backsound;
	
	
	boolean stage1_snd; 
	
	int X=200,Y=550;
	boolean sXL=false,sXR=false;
	float Scale_X;
	float Scale_Y;
	int xx, yy;
	BackThread thread1 = new BackThread();
	boolean thread1_pause=false;
	
	int ch_cnt1 = 0;
	int delay_time1=0;
	boolean delay_time1_sw=false; 
	int delay_time2=0;
	boolean delay_time2_sw=false; 
	int ch_width,ch_height;
	int th_sw_left=0, th_sw_right=0;
	int cloud_x[] = new int[3];
	int cloud_y[] = new int[3];
	
	
	public Img_View1(Context context){
		super(context);
	
		
		ch_Img[0] = (BitmapDrawable) context.getResources().getDrawable(R.drawable.ch1);
		ch_Img[1] = (BitmapDrawable) context.getResources().getDrawable(R.drawable.ch2);
		ch_Img[2] = (BitmapDrawable) context.getResources().getDrawable(R.drawable.ch3);
		Back_Img1 = (BitmapDrawable) context.getResources().getDrawable(R.drawable.back1);
		
		
		ch_width=492;
		ch_height=435;
		
		
		btn_left[0] = (BitmapDrawable) context.getResources().getDrawable(R.drawable.btn_left1);
		btn_left[1] = (BitmapDrawable) context.getResources().getDrawable(R.drawable.btn_left2);
		btn_right[0] = (BitmapDrawable) context.getResources().getDrawable(R.drawable.btn_right1);
		btn_right[1] = (BitmapDrawable) context.getResources().getDrawable(R.drawable.btn_right2);
		
		
		cloud_ch_img[0] = (BitmapDrawable) context.getResources().getDrawable(R.drawable.cloud1);
		cloud_ch_img[1] = (BitmapDrawable) context.getResources().getDrawable(R.drawable.cloud2);
		cloud_ch_img[2] = (BitmapDrawable) context.getResources().getDrawable(R.drawable.cloud3);
	
		
		for(int i=0;i<=2;i++)
			cloud_x_y_po(i);
		
		_context=context;
		stage1_snd = true;
		setEffects(_context,2);
		addSound(_context,0,R.raw.left); 
		addSound(_context,1,R.raw.right);
		
		backsound = MediaPlayer.create(_context, R.raw.free_back);
		
		
		thread1.setRunning(true);
		thread1.start();
	}
	//����ȿ��
	public void setEffects(Context cont, int number){
		msoundpool = new SoundPool(number, AudioManager.STREAM_MUSIC,0);
		msoundpoolmap = new HashMap<Integer, Integer>();
		maudiomanager = (AudioManager)cont.getSystemService(cont.AUDIO_SERVICE);
		vol = maudiomanager.getStreamVolume(AudioManager.STREAM_MUSIC);
	}
	//�����߰�
	public void addSound(Context cont, int ID, int name){
		msoundpoolmap.put(ID, msoundpool.load(cont, name, 1));
	}
	//�������
	public int playSound(int ID, int count, float speed){
		//���� ����ũ�⿡ ���� �����
		int vol = maudiomanager.getStreamVolume(AudioManager.STREAM_MUSIC);
		return msoundpool.play(msoundpoolmap.get(ID), vol, vol, 1, (count-1), speed);
	}
	//�������
	public void stopSound(int ID){
		msoundpool.stop(ID);
	}
	
	
	@Override
	public void onDraw(Canvas Canvas){
		Scale_X = Canvas.getWidth() / 480f;
		Scale_Y = Canvas.getHeight() / 800f;
		
		Canvas.scale(Scale_X, Scale_Y);
		
		Canvas.drawBitmap(Back_Img1.getBitmap(),0,0,null); 
		
		for (int i=0;i<3;i++){
			Rect cloud_size = new Rect(cloud_x[i],cloud_y[i],cloud_x[i]+ch_width/7,cloud_y[i]+ch_height/7);
			Canvas.drawBitmap(cloud_ch_img[i].getBitmap(),null,cloud_size,null );
		}
		
			
		Rect chh1 = new Rect(X,Y,X+ch_width/7, Y+ch_height/7);
		Canvas.drawBitmap(ch_Img[ch_cnt1].getBitmap(),null,chh1,null);
		
	
		Rect bnn_left = new Rect(20,710,20+137/2,710+154/2);
		Canvas.drawBitmap(btn_left[th_sw_left].getBitmap(),null,bnn_left,null);
		
		
		Rect bnn_right = new Rect(395,710,395+137/2,710+154/2);
		Canvas.drawBitmap(btn_right[th_sw_right].getBitmap(),null,bnn_right,null);
		
		
		
		Paint p = new Paint();
		Canvas.drawText("XX"+xx+" YY"+yy,10,30,p);
		Canvas.drawText("���Ƹ���: "+ch_Img[ch_cnt1].getBitmap().getWidth(),10,60,p);
		
		

		if(stage1_snd==true){
			stage1_snd=false; 
			backsound.setVolume(0.5f,0.5f);
			backsound.start();
			backsound.setLooping(true); 
		}
	}
	
	@Override
	public void onDetachedFromWindow(){
		stopSound(0);
		stopSound(1);
		backsound.stop();
		backsound.release();
		backsound=null;
		
		
		boolean retry1=true;
		thread1.setRunning(false); 
		while(retry1){
			try{
				thread1.join(); 
				retry1=false;
			}catch(InterruptedException e){}
		}
	}
	
	
	@Override
	public void onWindowVisibilityChanged(int visibility){
		super.onWindowVisibilityChanged(visibility);
		if(visibility==View.VISIBLE){ 
			backsound.start(); 
			thread1_pause=false;
		}else{ 
			backsound.pause();
			thread1_pause=true;
		}
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event){
		int action = event.getAction();
		
		xx = (int)(event.getX()/Scale_X);
		yy = (int)(event.getY()/Scale_Y);
		Rect rt = new Rect();
		
		if(event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE){
			
			rt.set(5,700,100,800);
			if(rt.contains(xx,yy)){
				sXL = true;
				th_sw_left=1;
				if(event.getAction() == MotionEvent.ACTION_DOWN){
					playSound(0,1,2f);
				}
			}
			rt.set(380,700,475,800);
			if(rt.contains(xx,yy)){
				sXR = true;
				th_sw_right=1;
				if(event.getAction() == MotionEvent.ACTION_DOWN){
					playSound(1,1,2f);
				}
			}
		}else{
			sXL=false;
			sXR=false;
			th_sw_left=0;
			th_sw_right=0;
		}
		return true;
	}
	
	class BackThread extends Thread{
		private boolean m_run=false;
		public void setRunning(boolean run){
			m_run=run;
		}
		public void run(){
			try{
				while(m_run){
					try{
						if(thread1_pause==false){
							Handler1.sendEmptyMessage(0);
							Thread.sleep(2);
						}
					}catch
						(InterruptedException e){;}
				}
			}catch(Exception exTot){}
		}
	}
	
	Handler Handler1 = new Handler(){
		public void handleMessage(Message msg){
			if(msg.what==0){
				delay_time50();
				delay_time3(); 
				cloud_mov();
				ch_img_sub();
				invalidate();
			}
		}
	};
	
	private void ch_img_sub(){
		if(sXL==true){
			if(X>=0){
				X-=1;
			}else{
				X=0;
			}
		}else if(sXR==true){
			if(X<=480-ch_width/7){
				X+=1;
			}else{
				X=480-ch_width/7;
			}
		}
		if(delay_time1_sw==true){
			ch_cnt1++;
			if(ch_cnt1>2){
				ch_cnt1=0;
			}
		}
		
	};
	private void cloud_mov(){ 
		
		if(delay_time2_sw==true)cloud_y[0]+=3;
		if(delay_time2_sw==true)cloud_y[1]+=1;
		if(delay_time2_sw==true)cloud_y[2]+=2;
		
		
		if(cloud_y[0]>900)cloud_x_y_po(0);
		if(cloud_y[1]>900)cloud_x_y_po(1);
		if(cloud_y[2]>900)cloud_x_y_po(2);
	};

	private void cloud_x_y_po(int cnt){ 
		Random rnd = new Random();

		int rnd_num_x = rnd.nextInt(400)+1;
		int rnd_num_y = rnd.nextInt(400)+200;

		cloud_x[cnt] = rnd_num_x;
		cloud_y[cnt] = -rnd_num_y;
	};
	
	private void delay_time50(){

		if(delay_time1 < 50){
			delay_time1_sw = false;
			delay_time1++;
		}else if(delay_time1 == 50){
			delay_time1_sw = true;
			delay_time1=0;
		}
	};
	private void delay_time3(){
		if(delay_time2<3){
			delay_time2_sw=false;
			delay_time2++;
		}else if(delay_time2==3){
			delay_time2_sw=true;
			delay_time2=0;
		}
	};
}
